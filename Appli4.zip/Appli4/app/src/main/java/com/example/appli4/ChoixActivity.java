package com.example.appli4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ChoixActivity extends AppCompatActivity {
    private Button mButton;
    private Button mButton2;
    private Button mButton3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choix);
        mButton=(Button) findViewById(R.id.activity_choix_bouton);
        mButton3=(Button) findViewById(R.id.activity_choix_bouton3);

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent choixplatactivity = new Intent(ChoixActivity.this, ChoixPlatAct.class);
                startActivity(choixplatactivity);
                // The user just clicked
            }
        });


        mButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent ListRestaurant = new Intent(ChoixActivity.this, ListRestaurant.class);
                startActivity(ListRestaurant);
                // The user just clicked
            }
        });
    }
}
