package com.example.appli4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class ListAct extends AppCompatActivity {
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private IngredientAdapter ingredientAdapter;
    @Override


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        List<Ingredient> listeCourse = new ArrayList<>();
        listeCourse.add(new Ingredient("Pizza 4 fromages ", "6€"));
        listeCourse.add(new Ingredient("Pizza Margarita", "5#"));
        listeCourse.add(new Ingredient("Pizza Reine", "7€"));
        listeCourse.add(new Ingredient("Pizza 4 Saisons", "6€"));
        listeCourse.add(new Ingredient("Pates Carbonara", "6€"));
        listeCourse.add(new Ingredient("Pates Bolognaise", "6€"));
        listeCourse.add(new Ingredient("Pates Pesto", "7€"));
        listeCourse.add(new Ingredient("Pates Fromage", "6€"));
        listeCourse.add(new Ingredient("Glace Chocolat", "4€"));
        listeCourse.add(new Ingredient("Glace Vanille", "4€"));


        // On récupère notre RecyclerView via son id
        recyclerView = findViewById(R.id.ingredient_recyclerview);

        // On veut un RecyclerView qui utilise un LinearLayoutManager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // On donne notre adapter à notre RecyclerView
        ingredientAdapter = new IngredientAdapter(listeCourse);
        recyclerView.setAdapter(ingredientAdapter);

        // On sépare chaque ligne de notre liste par un trait
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL);
        recyclerView.addItemDecoration(dividerItemDecoration);
    }
}
