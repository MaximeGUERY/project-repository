package com.example.appli4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

public class ListRestaurant extends AppCompatActivity {


    ListView listView;
    ArrayAdapter<String> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_restaurant);

        listView = (ListView) findViewById(R.id.listview);
        EditText Thefilter = (EditText) findViewById(R.id.searchfilter);

        String[] listeCourse = new String[]{
                "Restaurant A",
                "Restaurant B",
                "Restaurant C",
                "Restaurant D",
                "Restaurant E",
                "Restaurant F",
                "Restaurant G",
                "Restaurant H",
                "Restaurant I",
                "Restaurant J",
                "Restaurant K",
                "Restaurant L",
                "Restaurant M",
                "Restaurant N",
                "Restaurant O",
                "Restaurant P",

        };



       arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listeCourse);

        listView.setAdapter(arrayAdapter);

        Thefilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                (ListRestaurant.this).arrayAdapter.getFilter().filter(s);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                System.out.println("tu as cliqué sur le " + i + "eme item");

                String itemValue = (String) listView.getItemAtPosition(i);
                System.out.println("Valeur de l'item : " + itemValue);

                Intent listAct = new Intent(ListRestaurant.this, ListAct.class);
                startActivity(listAct);

            }



        });



    }
}
