package com.example.appli4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView mTexte1;
    private TextView mTexte2;
    private EditText mInput1;
    private Button mButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTexte1=(TextView) findViewById(R.id.activity_main_texte1);
        mTexte2=(TextView) findViewById(R.id.activity_main_texte2);
        mInput1=(EditText) findViewById(R.id.activity_main_input1);
        mButton=(Button) findViewById(R.id.activity_main_bouton);
        mButton.setEnabled(false);

        mInput1.addTextChangedListener(new TextWatcher() {
                                           @Override
                                           public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                                           }

                                           @Override
                                           public void onTextChanged(CharSequence s, int start, int before, int count) {
                                               mButton.setEnabled(s.toString().length() != 0);
                                           }

                                           @Override
                                           public void afterTextChanged(Editable s) {

                                           }

                                       }
        );

        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent ChoixActivity = new Intent(MainActivity.this, ChoixActivity.class);
                startActivity(ChoixActivity);
                // The user just clicked
            }
        });









    }
}
